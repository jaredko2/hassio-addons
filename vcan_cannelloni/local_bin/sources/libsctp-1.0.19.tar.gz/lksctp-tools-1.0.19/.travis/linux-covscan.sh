#!/bin/bash -x

KERNEL=master TRAVIS_BRANCH=none ./.travis/linux-build.sh
